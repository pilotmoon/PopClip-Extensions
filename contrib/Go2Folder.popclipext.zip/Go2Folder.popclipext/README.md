# Go2Folder PopClip Extension

## Description
Go2Folder opens the selected text as a folder path in Finder. The extension intelligently detects when selected text is a valid folder path and only appears in those cases.

## Usage
- Select any text that looks like a folder path (e.g. `/Users/yourname/Documents` or `~/Downloads`).
- The Go2Folder button will appear in PopClip **only when the text matches a path pattern**.
- Click the button to open the folder in Finder.
- If the path does not exist, an error message "Path does not exist" will be displayed.

## Features
- **Dynamic filtering**: The extension only appears when selected text resembles a path (starts with `/` or `~`).
- **Path validation**: Checks if the path exists before attempting to open it.
- **Tilde expansion**: Automatically expands `~` to your home directory.
- Works with both absolute paths (`/Applications`) and home-relative paths (`~/Documents`).
- Supports paths with spaces, hyphens, underscores, and dots.
- Clean feedback: Shows a checkmark on success or an error message if the path doesn't exist.

## Technical Details
- Uses PopClip's dynamic module system with JavaScript for intelligent path detection
- Validates paths using native macOS filesystem checks
- Opens folders using the `file://` URL scheme via PopClip's API

## Installation
1. Download or clone this repository
2. Double-click `Go2Folder.popclipext` or drag it to PopClip's preferences
3. The extension will be installed and ready to use

## Requirements
- PopClip version 4150 or higher
- macOS with PopClip installed

## Files
- `Config.yaml` - Extension metadata and configuration
- `Config.js` - JavaScript module for dynamic behavior
- `Open_Folder_Icon.png` - Custom folder icon
- `LICENSE` - MIT License
- `README.md` - This file

## Author
Created by **cptnweirdo**.

## License
MIT License - See LICENSE file for details.

## Changelog

### 2.0
- Complete rewrite using PopClip's dynamic module system
- Extension now only appears when text is a valid path format
- Added path existence validation with error messages
- Improved tilde expansion using native macOS APIs
- Better user feedback with status indicators
- Switched to `file://` URL opening method for better compatibility

### 1.1
- Added regex requirement for path detection
- Improved error handling with macOS notifications

### 1.0
- Initial release
exports.actions = (input) => {
  const text = input.text.trim();
  
  const pathPattern = /^[/~][A-Za-z0-9_/.\\-\s]*$/;
  
  if (pathPattern.test(text)) {
    return [{
      title: "Open",
      after: "show-result",
      code: (input) => {
        let path = input.text.trim();
        
        if (path.startsWith("~")) {
          const home = $.getenv("HOME");
          path = home + path.slice(1);
        }
        
        // Check if path exists
        const fileManager = $.NSFileManager.defaultManager;
        const pathExists = fileManager.fileExistsAtPath(path);
        
        if (pathExists) {
          const fileUrl = "file://" + encodeURI(path);
          popclip.openUrl(fileUrl);
          return null; // Success, show checkmark
        } else {
          throw new Error("Path does not exist");
        }
      }
    }];
  }
  
  return [];
};
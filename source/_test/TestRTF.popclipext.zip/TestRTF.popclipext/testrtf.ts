import { marked } from './marked.js'

export const action: ActionFunction = (input) => {
  const html = marked.parse(input.text)
  const rtf = util.htmlToRtf(html)
  pasteboard.content = { 'public.rtf': rtf }
}

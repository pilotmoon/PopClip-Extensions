"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.action = void 0;
const marked_js_1 = require("./marked.js");
const action = (input) => {
    const html = marked_js_1.marked.parse(input.text);
    const rtf = util.htmlToRtf(html);
    pasteboard.content = { 'public.rtf': rtf };
};
exports.action = action;
